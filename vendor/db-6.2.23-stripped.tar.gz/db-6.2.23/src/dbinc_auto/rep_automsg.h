/* Do not edit: automatically built by gen_msg.awk. */

#ifndef	__rep_AUTOMSG_H
#define	__rep_AUTOMSG_H

/*
 * Message sizes are simply the sum of field sizes (not
 * counting variable size parts, when DBTs are present),
 * and may be different from struct sizes due to padding.
 */
#define	__REP_BULK_SIZE	16
typedef struct ___rep_bulk_args {
	u_int32_t	len;
	DB_LSN		lsn;
	DBT		bulkdata;
} __rep_bulk_args;

#define	__REP_CONTROL_SIZE	36
typedef struct ___rep_control_args {
	u_int32_t	rep_version;
	u_int32_t	log_version;
	DB_LSN		lsn;
	u_int32_t	rectype;
	u_int32_t	gen;
	u_int32_t	msg_sec;
	u_int32_t	msg_nsec;
	u_int32_t	flags;
} __rep_control_args;

#define	__REP_EGEN_SIZE	4
typedef struct ___rep_egen_args {
	u_int32_t	egen;
} __rep_egen_args;

#define	__REP_FILEINFO_SIZE	48
typedef struct ___rep_fileinfo_args {
	u_int32_t	pgsize;
	db_pgno_t	pgno;
	db_pgno_t	max_pgno;
	u_int32_t	filenum;
	u_int32_t	finfo_flags;
	u_int32_t	type;
	u_int32_t	db_flags;
	DBT		uid;
	DBT		info;
	DBT		dir;
	u_int32_t	blob_fid_lo;
	u_int32_t	blob_fid_hi;
} __rep_fileinfo_args;

#define	__REP_FILEINFO_V7_SIZE	40
typedef struct ___rep_fileinfo_v7_args {
	u_int32_t	pgsize;
	db_pgno_t	pgno;
	db_pgno_t	max_pgno;
	u_int32_t	filenum;
	u_int32_t	finfo_flags;
	u_int32_t	type;
	u_int32_t	db_flags;
	DBT		uid;
	DBT		info;
	DBT		dir;
} __rep_fileinfo_v7_args;

#define	__REP_FILEINFO_V6_SIZE	36
typedef struct ___rep_fileinfo_v6_args {
	u_int32_t	pgsize;
	db_pgno_t	pgno;
	db_pgno_t	max_pgno;
	u_int32_t	filenum;
	u_int32_t	finfo_flags;
	u_int32_t	type;
	u_int32_t	db_flags;
	DBT		uid;
	DBT		info;
} __rep_fileinfo_v6_args;

#define	__REP_GRANT_INFO_SIZE	8
typedef struct ___rep_grant_info_args {
	u_int32_t	msg_sec;
	u_int32_t	msg_nsec;
} __rep_grant_info_args;

#define	__REP_LOGREQ_SIZE	8
typedef struct ___rep_logreq_args {
	DB_LSN		endlsn;
} __rep_logreq_args;

#define	__REP_NEWFILE_SIZE	4
typedef struct ___rep_newfile_args {
	u_int32_t	version;
} __rep_newfile_args;

#define	__REP_UPDATE_SIZE	16
typedef struct ___rep_update_args {
	DB_LSN		first_lsn;
	u_int32_t	first_vers;
	u_int32_t	num_files;
} __rep_update_args;

#define	__REP_VOTE_INFO_SIZE	28
typedef struct ___rep_vote_info_args {
	u_int32_t	egen;
	u_int32_t	nsites;
	u_int32_t	nvotes;
	u_int32_t	priority;
	u_int32_t	spare_pri;
	u_int32_t	tiebreaker;
	u_int32_t	data_gen;
} __rep_vote_info_args;

#define	__REP_VOTE_INFO_V5_SIZE	20
typedef struct ___rep_vote_info_v5_args {
	u_int32_t	egen;
	u_int32_t	nsites;
	u_int32_t	nvotes;
	u_int32_t	priority;
	u_int32_t	tiebreaker;
} __rep_vote_info_v5_args;

#define	__REP_LSN_HIST_KEY_SIZE	8
typedef struct ___rep_lsn_hist_key_args {
	u_int32_t	version;
	u_int32_t	gen;
} __rep_lsn_hist_key_args;

#define	__REP_LSN_HIST_DATA_SIZE	20
typedef struct ___rep_lsn_hist_data_args {
	u_int32_t	envid;
	DB_LSN		lsn;
	u_int32_t	hist_sec;
	u_int32_t	hist_nsec;
} __rep_lsn_hist_data_args;

#define	__REP_BLOB_UPDATE_REQ_SIZE	36
typedef struct ___rep_blob_update_req_args {
	u_int64_t	blob_fid;
	u_int64_t	blob_sid;
	u_int64_t	blob_id;
	u_int64_t	highest_id;
	u_int32_t	flags;
} __rep_blob_update_req_args;

#define	__REP_BLOB_UPDATE_REQ_V8_SIZE	32
typedef struct ___rep_blob_update_req_v8_args {
	u_int64_t	blob_fid;
	u_int64_t	blob_sid;
	u_int64_t	blob_id;
	u_int64_t	highest_id;
} __rep_blob_update_req_v8_args;

#define	__REP_BLOB_UPDATE_SIZE	24
typedef struct ___rep_blob_update_args {
	u_int64_t	blob_fid;
	u_int64_t	highest_id;
	u_int32_t	flags;
	u_int32_t	num_blobs;
} __rep_blob_update_args;

#define	__REP_BLOB_FILE_SIZE	24
typedef struct ___rep_blob_file_args {
	u_int64_t	blob_sid;
	u_int64_t	blob_id;
	u_int64_t	blob_size;
} __rep_blob_file_args;

#define	__REP_BLOB_CHUNK_SIZE	40
typedef struct ___rep_blob_chunk_args {
	u_int32_t	flags;
	u_int64_t	blob_fid;
	u_int64_t	blob_sid;
	u_int64_t	blob_id;
	u_int64_t	offset;
	DBT		data;
} __rep_blob_chunk_args;

#define	__REP_BLOB_CHUNK_REQ_SIZE	32
typedef struct ___rep_blob_chunk_req_args {
	u_int64_t	blob_fid;
	u_int64_t	blob_sid;
	u_int64_t	blob_id;
	u_int64_t	offset;
} __rep_blob_chunk_req_args;

#define	__REP_MAXMSG_SIZE	48
#endif
